/*
 * Copyright (C) 2018 CS ROMANIA
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 3 of the License, or (at your option)
 * any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, see http://www.gnu.org/licenses/
 */

package ro.cs.tao.execution.monitor;

/**
 * A class representing system information, including resource metrics such as the number
 * of logical processors, memory statistics, and disk usage metrics.
 *
 * This class provides getter and setter methods to access and modify the system's
 * hardware and resource attributes.
 */
public class SysInfo {
    private int logicalProcessors;
    private long availableMemory;
    private long totalMemory;
    private long availableDiskSize;
    private long totalDiskSize;

    public int getLogicalProcessors() {
        return logicalProcessors;
    }

    public void setLogicalProcessors(int logicalProcessors) {
        this.logicalProcessors = logicalProcessors;
    }

    public long getAvailableMemory() {
        return availableMemory;
    }

    public void setAvailableMemory(long availableMemory) {
        this.availableMemory = availableMemory;
    }

    public long getTotalMemory() {
        return totalMemory;
    }

    public void setTotalMemory(long totalMemory) {
        this.totalMemory = totalMemory;
    }

    public long getAvailableDiskSize() {
        return availableDiskSize;
    }

    public void setAvailableDiskSize(long availableDiskSize) {
        this.availableDiskSize = availableDiskSize;
    }

    public long getTotalDiskSize() {
        return totalDiskSize;
    }

    public void setTotalDiskSize(long totalDiskSize) {
        this.totalDiskSize = totalDiskSize;
    }
}
