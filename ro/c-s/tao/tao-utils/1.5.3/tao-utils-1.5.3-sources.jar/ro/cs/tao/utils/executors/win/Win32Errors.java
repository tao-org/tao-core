/*
 * Copyright (C) 2018 CS ROMANIA
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 3 of the License, or (at your option)
 * any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, see http://www.gnu.org/licenses/
 */
package ro.cs.tao.utils.executors.win;

/**
 * @author Cosmin Cara
 */
public interface Win32Errors {
    int NO_ERROR               = 0;
    int ERROR_INVALID_FUNCTION = 1;
    int ERROR_FILE_NOT_FOUND   = 2;
    int ERROR_PATH_NOT_FOUND   = 3;
}
