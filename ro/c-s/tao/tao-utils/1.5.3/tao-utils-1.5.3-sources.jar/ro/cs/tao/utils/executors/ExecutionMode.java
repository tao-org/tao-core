/*
 * Copyright (C) 2018 CS ROMANIA
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 3 of the License, or (at your option)
 * any later version.
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, see http://www.gnu.org/licenses/
 */
package ro.cs.tao.utils.executors;

/**
 * Represents the execution mode for a system or process.
 *
 * This enumeration defines two execution modes:
 * - {@link #SUPERUSER}: Represents a mode where elevated privileges are granted.
 * - {@link #USER}: Represents a mode with standard user privileges.
 *
 * @author Cosmin Cara
 */
public enum ExecutionMode {
    SUPERUSER(true),
    USER(false);

    private final boolean mode;

    ExecutionMode(final boolean mode) { this.mode = mode; }

    @Override
    public String toString() { return this.mode ? "SUPERUSER" : "USER"; }

    public boolean value() { return this.mode; }
}
